/*
 * Danny Do
 * CS141
 * Assignment 5
 * 06/01/18
 */

public class ParkingMeter {
	int minutesPurchased;
	
	public ParkingMeter(int mp) {
		minutesPurchased = mp;
	}
	
	//setter and getters
	public int getMinutesPurchased() {
		return minutesPurchased;
	}
	public void setMinutesPurchased(int minutesPurchased) {
		this.minutesPurchased = minutesPurchased;
	}
	
}
